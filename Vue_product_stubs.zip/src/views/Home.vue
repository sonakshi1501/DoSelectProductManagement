<template>
    <div>
      <h1>Home</h1>
    </div>
  </template>
  
  <script>
  export default {
    name: 'Home',
  };
  </script>
  
  <style scoped>
  h1 {
    color: #42b983;
  }
  </style>
  