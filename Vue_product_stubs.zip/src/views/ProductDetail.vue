<template>
  <div class="container">
    <div class="card mt-4">
      <img  class="card-img-top" alt="Product Image">
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: 'ProductDetail',
  data() {
    return {
      product: {},
    };
  },
  // Write Code Here
};
</script>

<style scoped>
h1 {
  color: #42b983;
}
</style>
