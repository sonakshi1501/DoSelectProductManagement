<template>
    <div class="container">
      <h1>Products</h1>
      <div class="row">
        <div class="col-md-4" >
          <div class="card mb-4">
            <img class="card-img-top" alt="Product Image">
            <!-- Write Code Here -->
          </div>
        </div>
      </div>
    </div>
  </template>
  
  <script>
  
  export default {
    name: 'Products',
  //  Write code here in order to acces the fetchProducts Api
  };
  </script>
  
  <style scoped>
  h1 {
    color: #42b983;
  }
  </style>
  