import { createStore } from 'vuex';

export default createStore({
  state: {
    // Write Code Here
  },
  mutations: {
    // Write Code Here
  },
  actions: {
    // Write Code Here
  },
  modules: {},
});
